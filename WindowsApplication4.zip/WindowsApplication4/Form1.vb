﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Data.OleDb

Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim OleConn As New OleDb.OleDbConnection
    Dim OleReader As OleDb.OleDbDataReader
    Dim myConn As SqlConnection
    Dim Cmd As New SqlCommand
    Dim myReader As SqlDataReader
    Dim results As String
    Dim textbox1 As New TextBox
    Dim oriGin As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source="
    Dim secSchtuff As String = ";Persist Security Info=True;Jet OLEDB:Database Password=time2634"
    Dim bawsQuery = "SELECT MSysObjects.Name AS table_name FROM MSysObjects WHERE (((Left([Name],1))<>""~"") AND ((Left([Name],4))<>""MSys"") AND ((MSysObjects.Type) In (1,4,6))) order by MSysObjects.Name"

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Create an sql connecction object
        myConn = New SqlConnection("Data Source=" & Environment.MachineName & "; Initial Catalog=master; Integrated Security=True;")

        'Grab data from SQL database
        Dim myCmd As SqlDataAdapter = New SqlDataAdapter("EXEC sp_databases", myConn)
        Dim myData As New DataSet("tpDataSQL")

        'Makin' a string array
        Dim nameList As New List(Of String)

        myConn.Open()

        'READ FROM ACCESS DATABASE
        myCmd.FillSchema(myData, SchemaType.Source, "tblJob")
        myCmd.Fill(myData, "tblJob")

        'MAKE A DATATABLE
        Dim tblJob As DataTable
        tblJob = myData.Tables("tblJob")

        'DISPLAY DATATABLE
        Dim drCurrent As DataRow
        For Each drCurrent In tblJob.Rows
            ListBox1.Items.Add(drCurrent("DATABASE_NAME"))
        Next
        Console.WriteLine(bawsQuery)
        Console.ReadLine()
        myConn.Close()

    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dialog As New OpenFileDialog()
        dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
        dialog.Filter = "mdb files (*.mdb)|*.mdb|All files (*.*)|*.*"
        If DialogResult.OK = dialog.ShowDialog Then
            textbox1.Text = dialog.FileName
            OleConn.ConnectionString = oriGin & textbox1.Text & secSchtuff
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Dim curItem As String = ListBox1.SelectedItem.ToString()
            myConn.ConnectionString = "Data Source=" & Environment.MachineName & "; Initial Catalog=" & ListBox1.SelectedItem.ToString() & "; Integrated Security=True;"
            Console.WriteLine(myConn.ConnectionString)
        Catch ex As Exception
            MsgBox("oops: " & vbCrLf & ex.Message)
        End Try
        konnekt()
    End Sub

    Function konnekt()
        Try
            myConn.Open()
            Console.WriteLine(myConn.State)
            OleConn.Open()
            Console.WriteLine(OleConn.State)
            Dim currentTable As String = "tblJob"
            Dim OleCmd1 = New OleDbCommand(bawsQuery, OleConn)
            Dim OleCmd = New OleDb.OleDbCommand("select * from " & currentTable, OleConn) '************good
            OleReader = OleCmd.ExecuteReader()
            While OleReader.Read()
                Dim datum As String = Nothing
                For columns = 0 To OleReader.FieldCount - 1
                    datum = datum & "," & OleReader.Item(columns)
                    Console.WriteLine(datum)
                Next
                datum = datum.Substring(1, (datum.Length - 1))
                MsgBox(datum)
                Console.WriteLine("INSERT INTO " & currentTable & " VALUES " & datum & "")
                'Cmd.CommandText = "INSERT INTO " & currentTable & " VALUES " & datum & ""
                'Cmd.Connection = myConn
                'Cmd.ExecuteNonQuery()
                Console.ReadLine()
            End While

        Catch ex As Exception
            MsgBox("oops: " & vbCrLf & ex.Message)
        End Try
        OleConn.Close()
        myConn.Close()
        Return Nothing
    End Function

End Class